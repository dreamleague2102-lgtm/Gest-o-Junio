import { Bill } from "./types";

export const initialBills: Bill[] = [
  { id: "1", description: "Alex", amount: 280, dueDate: "15/04/2026", paid: false },
  { id: "2", description: "Faculdade", amount: 150, dueDate: "15/04/2026", paid: false },
  { id: "3", description: "Israel", amount: 200, dueDate: "15/04/2026", paid: false },
  { id: "4", description: "Notebook", amount: 244, dueDate: "30/04/2026", paid: false },
  { id: "5", description: "Plano", amount: 75, dueDate: "30/04/2026", paid: false },
  { id: "6", description: "Rebeca", amount: 115, dueDate: "15/04/2026", paid: false },
  { id: "7", description: "Colchão", amount: 180, dueDate: "15/04/2026", paid: false },
  { id: "8", description: "iPhone", amount: 430, dueDate: "30/04/2026", paid: false },
  { id: "9", description: "Mensal", amount: 200, dueDate: "30/04/2026", paid: false },
  { id: "10", description: "Rebeca", amount: 115, dueDate: "30/04/2026", paid: false },
  { id: "11", description: "Daniel", amount: 395, dueDate: "A definir", paid: false },
];
