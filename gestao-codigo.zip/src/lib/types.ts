export interface Bill {
  id: string;
  description: string;
  amount: number;
  dueDate: string;
  paid: boolean;
  paidDate?: string;
}

export interface MonthData {
  month: string; // "2026-04"
  bills: Bill[];
}
