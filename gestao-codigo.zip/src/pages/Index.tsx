import { useState, useEffect } from "react";
import { Bill, MonthData } from "@/lib/types";
import { initialBills } from "@/lib/initialData";
import BillChart from "@/components/BillChart";
import BillTable from "@/components/BillTable";
import AddBillForm from "@/components/AddBillForm";
import SummaryCards from "@/components/SummaryCards";
import BiweeklyCards from "@/components/BiweeklyCards";
import DebtsByDate from "@/components/DebtsByDate";
import MonthSelector from "@/components/MonthSelector";
import { toast } from "sonner";

const STORAGE_KEY = "junio-contas";
const SALARY_KEY = "junio-salary-biweekly";

const getCurrentMonthKey = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
};

const loadData = (): Record<string, Bill[]> => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch {}
  return { "2026-04": initialBills };
};

const saveData = (data: Record<string, Bill[]>) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

const Index = () => {
  const [allData, setAllData] = useState<Record<string, Bill[]>>(loadData);
  const [currentMonth, setCurrentMonth] = useState("2026-04");
  const [salaryBiweekly, setSalaryBiweekly] = useState<{ first: number; second: number }>(() => {
    try {
      const saved = localStorage.getItem(SALARY_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return { first: 970, second: 590 };
  });

  const handleSalaryChange = (first: number, second: number) => {
    const next = { first, second };
    setSalaryBiweekly(next);
    localStorage.setItem(SALARY_KEY, JSON.stringify(next));
    toast.success("Valores atualizados!");
  };

  const bills = allData[currentMonth] || [];

  useEffect(() => {
    saveData(allData);
  }, [allData]);

  useEffect(() => {
    const MIGRATION_KEY = "junio-salary-migrated-v2";
    if (!localStorage.getItem(MIGRATION_KEY)) {
      const next = { first: 970, second: 590 };
      setSalaryBiweekly(next);
      localStorage.setItem(SALARY_KEY, JSON.stringify(next));
      localStorage.setItem(MIGRATION_KEY, "1");
    }
  }, []);

  const updateBills = (newBills: Bill[]) => {
    setAllData((prev) => ({ ...prev, [currentMonth]: newBills }));
  };

  const handleAdd = (description: string, amount: number, dueDate: string) => {
    const newBill: Bill = {
      id: crypto.randomUUID(),
      description,
      amount,
      dueDate,
      paid: false,
    };
    updateBills([...bills, newBill]);
    toast.success("Conta adicionada!");
  };

  const handleTogglePaid = (id: string) => {
    updateBills(
      bills.map((b) =>
        b.id === id ? { ...b, paid: !b.paid, paidDate: !b.paid ? new Date().toLocaleDateString("pt-BR") : undefined } : b
      )
    );
  };

  const handleDelete = (id: string) => {
    updateBills(bills.filter((b) => b.id !== id));
    toast.info("Conta removida.");
  };

  const navigateMonth = (dir: number) => {
    const [y, m] = currentMonth.split("-").map(Number);
    const d = new Date(y, m - 1 + dir, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    if (!allData[key]) {
      setAllData((prev) => ({ ...prev, [key]: [] }));
    }
    setCurrentMonth(key);
  };

  const handleNewMonth = () => {
    const [y, m] = currentMonth.split("-").map(Number);
    const d = new Date(y, m, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    if (!allData[key]) {
      setAllData((prev) => ({ ...prev, [key]: [] }));
    }
    setCurrentMonth(key);
    toast.success("Novo mês criado! Adicione suas contas.");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card shadow-sm">
        <div className="container max-w-4xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-foreground">💰 Gestão</h1>
          <p className="text-sm text-muted-foreground">Controle financeiro mensal</p>
        </div>
      </header>
      <main className="container max-w-4xl mx-auto px-4 py-6 space-y-6">
        <MonthSelector
          currentMonth={currentMonth}
          onPrev={() => navigateMonth(-1)}
          onNext={() => navigateMonth(1)}
          onNewMonth={handleNewMonth}
        />
        <SummaryCards bills={bills} salary={salaryBiweekly.first + salaryBiweekly.second} />
        <BiweeklyCards
          bills={bills}
          salaryFirst={salaryBiweekly.first}
          salarySecond={salaryBiweekly.second}
          onSalaryChange={handleSalaryChange}
        />
        <DebtsByDate bills={bills} />
        <BillChart bills={bills} />
        <AddBillForm onAdd={handleAdd} />
        <BillTable bills={bills} onTogglePaid={handleTogglePaid} onDelete={handleDelete} />
      </main>
    </div>
  );
};

export default Index;
