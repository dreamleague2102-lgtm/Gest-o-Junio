import { Bill } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, X, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface BillTableProps {
  bills: Bill[];
  onTogglePaid: (id: string) => void;
  onDelete: (id: string) => void;
}

const BillTable = ({ bills, onTogglePaid, onDelete }: BillTableProps) => {
  const formatCurrency = (v: number) =>
    v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Contas do Mês</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-medium text-muted-foreground">Descrição</th>
                <th className="text-right p-3 font-medium text-muted-foreground">Valor</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Vencimento</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Ações</th>
              </tr>
            </thead>
            <tbody>
              {bills.map((bill) => (
                <tr key={bill.id} className={cn("border-b transition-colors", bill.paid && "bg-success/5")}>
                  <td className={cn("p-3 font-medium", bill.paid && "line-through text-muted-foreground")}>
                    {bill.description}
                  </td>
                  <td className="p-3 text-right font-mono">{formatCurrency(bill.amount)}</td>
                  <td className="p-3 text-center text-muted-foreground">{bill.dueDate}</td>
                  <td className="p-3 text-center">
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium",
                        bill.paid ? "bg-success/15 text-success" : "bg-warning/15 text-warning"
                      )}
                    >
                      {bill.paid ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                      {bill.paid ? "Pago" : "Pendente"}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Button
                        size="sm"
                        variant={bill.paid ? "outline" : "default"}
                        className="h-8 text-xs"
                        onClick={() => onTogglePaid(bill.id)}
                      >
                        {bill.paid ? "Desfazer" : "Pagar"}
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => onDelete(bill.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {bills.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-muted-foreground">
                    Nenhuma conta cadastrada. Adicione uma nova conta acima.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default BillTable;
