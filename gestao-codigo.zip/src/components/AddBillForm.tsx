import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus } from "lucide-react";

interface AddBillFormProps {
  onAdd: (description: string, amount: number, dueDate: string) => void;
}

const AddBillForm = ({ onAdd }: AddBillFormProps) => {
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount) return;
    const parsed = parseFloat(amount.replace(",", "."));
    if (isNaN(parsed)) return;
    onAdd(description, parsed, dueDate || "A definir");
    setDescription("");
    setAmount("");
    setDueDate("");
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Adicionar Conta</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
          <Input placeholder="Descrição" value={description} onChange={(e) => setDescription(e.target.value)} className="flex-1" />
          <Input placeholder="Valor (R$)" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full sm:w-32" />
          <Input placeholder="Vencimento" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="w-full sm:w-36" />
          <Button type="submit" className="gap-1">
            <Plus className="h-4 w-4" /> Adicionar
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default AddBillForm;
