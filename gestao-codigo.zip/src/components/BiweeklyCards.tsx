import { useState } from "react";
import { Bill } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Calendar, Pencil, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BiweeklyCardsProps {
  bills: Bill[];
  salaryFirst: number;
  salarySecond: number;
  onSalaryChange: (first: number, second: number) => void;
}

const fmt = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const getDay = (due: string) => {
  // Aceita "DD/MM/YYYY", "YYYY-MM-DD" ou "DD"
  if (!due) return 0;
  if (due.includes("/")) return parseInt(due.split("/")[0], 10) || 0;
  if (due.includes("-")) {
    const parts = due.split("-");
    return parseInt(parts[2] || parts[0], 10) || 0;
  }
  return parseInt(due, 10) || 0;
};

const BiweeklyCards = ({ bills, salaryFirst, salarySecond, onSalaryChange }: BiweeklyCardsProps) => {
  const [editing, setEditing] = useState(false);
  const [first, setFirst] = useState(salaryFirst);
  const [second, setSecond] = useState(salarySecond);

  const firstBills = bills.filter((b) => getDay(b.dueDate) <= 15);
  const secondBills = bills.filter((b) => getDay(b.dueDate) > 15);

  const firstExpenses = firstBills.reduce((s, b) => s + b.amount, 0);
  const secondExpenses = secondBills.reduce((s, b) => s + b.amount, 0);

  const firstBalance = salaryFirst - firstExpenses;
  const secondBalance = salarySecond - secondExpenses;

  const save = () => {
    onSalaryChange(first, second);
    setEditing(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Por quinzena</h2>
        {editing ? (
          <Button size="sm" variant="outline" onClick={save}>
            <Check className="h-4 w-4 mr-1" /> Salvar
          </Button>
        ) : (
          <Button size="sm" variant="ghost" onClick={() => setEditing(true)}>
            <Pencil className="h-4 w-4 mr-1" /> Editar valores
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* 1ª Quinzena */}
        <Card className="border-l-4 border-l-primary">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center gap-2">
              <div className="rounded-full bg-primary/10 p-2">
                <Calendar className="h-4 w-4 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground">1ª Quinzena (até dia 15)</h3>
            </div>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Pagamento</span>
                {editing ? (
                  <Input
                    type="number"
                    value={first}
                    onChange={(e) => setFirst(Number(e.target.value))}
                    className="h-7 w-28 text-right"
                  />
                ) : (
                  <span className="font-medium text-foreground">{fmt(salaryFirst)}</span>
                )}
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dívidas ({firstBills.length})</span>
                <span className="font-medium text-destructive">- {fmt(firstExpenses)}</span>
              </div>
              <div className="border-t pt-2 flex justify-between">
                <span className="font-semibold text-foreground">Saldo</span>
                <span className={`font-bold ${firstBalance >= 0 ? "text-success" : "text-destructive"}`}>
                  {fmt(firstBalance)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 2ª Quinzena */}
        <Card className="border-l-4 border-l-primary">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center gap-2">
              <div className="rounded-full bg-primary/10 p-2">
                <Calendar className="h-4 w-4 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground">2ª Quinzena (após dia 15)</h3>
            </div>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Pagamento</span>
                {editing ? (
                  <Input
                    type="number"
                    value={second}
                    onChange={(e) => setSecond(Number(e.target.value))}
                    className="h-7 w-28 text-right"
                  />
                ) : (
                  <span className="font-medium text-foreground">{fmt(salarySecond)}</span>
                )}
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dívidas ({secondBills.length})</span>
                <span className="font-medium text-destructive">- {fmt(secondExpenses)}</span>
              </div>
              <div className="border-t pt-2 flex justify-between">
                <span className="font-semibold text-foreground">Saldo</span>
                <span className={`font-bold ${secondBalance >= 0 ? "text-success" : "text-destructive"}`}>
                  {fmt(secondBalance)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BiweeklyCards;
