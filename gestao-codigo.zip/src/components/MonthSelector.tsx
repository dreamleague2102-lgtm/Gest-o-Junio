import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";

interface MonthSelectorProps {
  currentMonth: string;
  onPrev: () => void;
  onNext: () => void;
  onNewMonth: () => void;
}

const MONTH_NAMES = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

const MonthSelector = ({ currentMonth, onPrev, onNext, onNewMonth }: MonthSelectorProps) => {
  const [year, month] = currentMonth.split("-").map(Number);
  const label = `${MONTH_NAMES[month - 1]} ${year}`;

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon" onClick={onPrev}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <h2 className="text-xl font-bold text-foreground min-w-[180px] text-center">{label}</h2>
        <Button variant="outline" size="icon" onClick={onNext}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
      <Button variant="outline" className="gap-1" onClick={onNewMonth}>
        <RotateCcw className="h-4 w-4" /> Novo Mês
      </Button>
    </div>
  );
};

export default MonthSelector;
