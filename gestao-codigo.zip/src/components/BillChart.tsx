import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { Bill } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface BillChartProps {
  bills: Bill[];
}

const BillChart = ({ bills }: BillChartProps) => {
  const totalPaid = bills.filter((b) => b.paid).reduce((s, b) => s + b.amount, 0);
  const totalPending = bills.filter((b) => !b.paid).reduce((s, b) => s + b.amount, 0);
  const total = totalPaid + totalPending;

  const data = [
    { name: "Pago", value: totalPaid },
    { name: "Pendente", value: totalPending },
  ];

  const COLORS = ["hsl(160, 60%, 45%)", "hsl(210, 80%, 45%)"];

  const formatCurrency = (v: number) =>
    v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Resumo do Mês</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-3 mb-4 text-center">
          <div className="rounded-lg bg-secondary p-3">
            <p className="text-xs text-muted-foreground">Total</p>
            <p className="text-lg font-bold text-foreground">{formatCurrency(total)}</p>
          </div>
          <div className="rounded-lg bg-success/10 p-3">
            <p className="text-xs text-muted-foreground">Pago</p>
            <p className="text-lg font-bold text-success">{formatCurrency(totalPaid)}</p>
          </div>
          <div className="rounded-lg bg-primary/10 p-3">
            <p className="text-xs text-muted-foreground">Pendente</p>
            <p className="text-lg font-bold text-primary">{formatCurrency(totalPending)}</p>
          </div>
        </div>
        {total > 0 && (
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={data} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" strokeWidth={2}>
                {data.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip formatter={(v: number) => formatCurrency(v)} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};

export default BillChart;
