import { Bill } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, Wallet } from "lucide-react";

interface SummaryCardsProps {
  bills: Bill[];
  salary: number;
}

const SummaryCards = ({ bills, salary }: SummaryCardsProps) => {
  const totalExpenses = bills.reduce((sum, b) => sum + b.amount, 0);
  const balance = salary - totalExpenses;

  const fmt = (v: number) =>
    v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <Card className="border-l-4 border-l-primary">
        <CardContent className="flex items-center gap-4 p-4">
          <div className="rounded-full bg-primary/10 p-3">
            <DollarSign className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Pagamento</p>
            <p className="text-2xl font-bold text-foreground">{fmt(salary)}</p>
          </div>
        </CardContent>
      </Card>
      <Card className={`border-l-4 ${balance >= 0 ? "border-l-success" : "border-l-destructive"}`}>
        <CardContent className="flex items-center gap-4 p-4">
          <div className={`rounded-full p-3 ${balance >= 0 ? "bg-success/10" : "bg-destructive/10"}`}>
            <Wallet className={`h-6 w-6 ${balance >= 0 ? "text-success" : "text-destructive"}`} />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Saldo</p>
            <p className={`text-2xl font-bold ${balance >= 0 ? "text-success" : "text-destructive"}`}>{fmt(balance)}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SummaryCards;
