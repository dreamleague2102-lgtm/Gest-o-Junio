import { Bill } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { CalendarDays } from "lucide-react";

interface DebtsByDateProps {
  bills: Bill[];
}

const fmt = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const normalizeDate = (due: string): string => {
  if (!due) return "—";
  if (due.includes("/")) return due; // já DD/MM/YYYY
  if (due.includes("-")) {
    const [y, m, d] = due.split("-");
    if (y && m && d) return `${d}/${m}/${y}`;
    return due;
  }
  return `Dia ${due}`;
};

const sortKey = (due: string): number => {
  if (!due) return 0;
  if (due.includes("/")) {
    const [d, m, y] = due.split("/").map(Number);
    return new Date(y || 0, (m || 1) - 1, d || 1).getTime();
  }
  if (due.includes("-")) {
    const [y, m, d] = due.split("-").map(Number);
    return new Date(y || 0, (m || 1) - 1, d || 1).getTime();
  }
  return parseInt(due, 10) || 0;
};

const DebtsByDate = ({ bills }: DebtsByDateProps) => {
  if (bills.length === 0) return null;

  const groups = bills.reduce<Record<string, { total: number; count: number; key: number }>>(
    (acc, b) => {
      const label = normalizeDate(b.dueDate);
      if (!acc[label]) acc[label] = { total: 0, count: 0, key: sortKey(b.dueDate) };
      acc[label].total += b.amount;
      acc[label].count += 1;
      return acc;
    },
    {}
  );

  const entries = Object.entries(groups).sort((a, b) => a[1].key - b[1].key);
  const total = bills.reduce((s, b) => s + b.amount, 0);

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold text-foreground">Dívidas por data</h2>
      <Card>
        <CardContent className="p-4 space-y-2">
          {entries.map(([label, { total: t, count }]) => (
            <div
              key={label}
              className="flex justify-between items-center text-sm py-1 border-b last:border-b-0"
            >
              <div className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-primary" />
                <span className="font-medium text-foreground">{label}</span>
                <span className="text-muted-foreground text-xs">
                  ({count} {count === 1 ? "conta" : "contas"})
                </span>
              </div>
              <span className="font-semibold text-destructive">{fmt(t)}</span>
            </div>
          ))}
          <div className="flex justify-between items-center pt-2 border-t mt-2">
            <span className="font-semibold text-foreground">Total geral</span>
            <span className="font-bold text-destructive">{fmt(total)}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DebtsByDate;
